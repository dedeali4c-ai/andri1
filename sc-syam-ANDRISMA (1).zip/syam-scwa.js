'use strict';
module.exports = require('./syamkey').loadExport("syam-scwa");
