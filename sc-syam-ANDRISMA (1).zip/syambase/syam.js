'use strict';
module.exports = require('../syamkey').loadExport("syambase/syam");
