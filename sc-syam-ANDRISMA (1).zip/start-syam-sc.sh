#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1
export SYAM_WRAPPER=1
echo "[SYAM-SC] start — auto-restart aktif (update dipasang -> restart otomatis)"
while true; do
	node index.js
	code=$?
	echo "[SYAM-SC] index.js keluar (exit $code) — restart 4 dtk…"
	sleep 4
done
