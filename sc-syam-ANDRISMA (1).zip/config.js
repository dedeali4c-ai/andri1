
global.owner = [
  "6285156669858"
]
global.usePairingCode = true

global.minimaxApiKey = ""
global.minimaxModel = "MiniMax-M2"

global.payment = {
  qris: "",
  dana: "",
  ovo: "",
  gopay: "",
  shopee: ""
}


let fs = require('fs')
let file = require.resolve(__filename)
const reloadSelf = () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
try {
require(file)
} catch (e) {
console.log(`[ reload ] file invalid / belum kelar disave, reload di-skip:`, e?.message || e)
fs.watchFile(file, reloadSelf)
}
}
fs.watchFile(file, reloadSelf)
