'use strict';
require('./syamkey').runMain("index");
