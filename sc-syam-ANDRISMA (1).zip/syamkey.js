'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const Module = require('module');

const MAGIC = Buffer.from('SYJS01', 'ascii');
const ALGO = 'aes-256-gcm';
const IV_LEN = 12;
const TAG_LEN = 16;
const ROOT = __dirname;
const ENC_DIR = path.join(ROOT, '.syam-enc');

const _k = ["5c36862dbbc2ecdb", "3b5e76bca7324222", "32d61677fca99c35", "8c10fc1a86d38e90"].join('');

function packKey() {
  return Buffer.from(_k, 'hex');
}

function payloadKey() {
  // 1) kunci hasil unwrap proses ini (shell v12 set global.__SYAM_SC_KEY)
  try {
    const g = global.__SYAM_SC_KEY;
    if (g && String(g).trim().length >= 32) return toKeyBuf(String(g).trim());
  } catch (_) {}
  // 2) cache lokal terenkripsi, terikat token bot + sidik jari mesin
  try {
    const gd = require('./syamguard');
    const token = String(process.env.BOT_TOKEN || process.env.SYAM_SC_BOT_TOKEN || '').trim();
    const scId = String(process.env.SYAM_SC_ID || (function () {
      try { return JSON.parse(fs.readFileSync(path.join(ROOT, 'syam-meta.json'), 'utf8')).scId; } catch (_) { return ''; }
    })() || 'tele');
    if (token && gd && gd.loadCachedKey) {
      const k = gd.loadCachedKey(token, scId, gd.machineId());
      if (k && String(k).trim().length >= 32) return toKeyBuf(String(k).trim());
    }
  } catch (_) {}
  // 3) file kunci lama (install/shell lawas)
  try {
    const p = path.join(ENC_DIR, '.payload-key');
    if (fs.existsSync(p)) {
      const raw = fs.readFileSync(p, 'utf8').trim();
      if (raw.length >= 32) return toKeyBuf(raw);
    }
  } catch (_) {}
  return null;
}

function toKeyBuf(raw) {
  if (/^[0-9a-fA-F]{64}$/.test(raw)) return Buffer.from(raw.slice(0, 64), 'hex');
  return Buffer.from(raw.slice(0, 32), 'utf8');
}

function keyFor(logical) {
  if (logical === 'SYAMXXXX' && payloadKey()) return payloadKey();
  return packKey();
}

function decryptFile(logical) {
  const fp = path.join(ENC_DIR, logical + '.enc');
  if (!fs.existsSync(fp)) {
    throw new Error('[SYAM-ENC] missing blob: ' + logical + '.enc');
  }
  const buf = fs.readFileSync(fp);
  if (buf.length < MAGIC.length + IV_LEN + TAG_LEN + 1 || !buf.subarray(0, MAGIC.length).equals(MAGIC)) {
    throw new Error('[SYAM-ENC] bad blob: ' + logical);
  }
  let o = MAGIC.length;
  const iv = buf.subarray(o, o + IV_LEN); o += IV_LEN;
  const tag = buf.subarray(o, o + TAG_LEN); o += TAG_LEN;
  const data = buf.subarray(o);
  const decipher = crypto.createDecipheriv(ALGO, keyFor(logical), iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(data), decipher.final()]).toString('utf8');
}

const _cache = Object.create(null);

function compileModule(logical, code) {
  const filename = path.join(ROOT, logical + '.js');
  const m = new Module(filename, module);
  m.filename = filename;
  m.paths = Module._nodeModulePaths(ROOT);
  m._compile(code, filename);
  return m;
}

function loadExport(logical) {
  if (_cache[logical] && _cache[logical].exports) return _cache[logical].exports;
  const code = decryptFile(logical);
  const m = compileModule(logical, code);
  _cache[logical] = m;
  return m.exports;
}

function runMain(logical) {
  if (_cache[logical]) return _cache[logical].exports;
  const code = decryptFile(logical);
  const m = compileModule(logical, code);
  _cache[logical] = m;
  return m.exports;
}

module.exports = { loadExport, runMain, decryptFile };
